﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ConfiguraionDemo
{
    public class ProjectDetails
    {
        public string Title { get; set; }
        public int Duration { get; set; }
        public string Status { get; set; }
    }
}
