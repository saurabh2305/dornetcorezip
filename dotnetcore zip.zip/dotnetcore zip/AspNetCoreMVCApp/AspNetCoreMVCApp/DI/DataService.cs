﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AspNetCoreMVCApp.DI
{
    public class DataService
    {
        public string Message { get; set; }
    }
}
